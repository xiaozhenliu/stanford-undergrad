// This is the CPP file you will edit and turn in. (TODO: Remove this comment!)

#include "VectorPatientQueue.h"

VectorPatientQueue::VectorPatientQueue() {
    // TODO: write this constructor
}

VectorPatientQueue::~VectorPatientQueue() {
    // TODO: write this destructor
}

void VectorPatientQueue::clear() {
    // TODO: write this function
}

string VectorPatientQueue::frontName() {
    // TODO: write this function
    return "";   // this is only here so it will compile
}

int VectorPatientQueue::frontPriority() {
    // TODO: write this function
    return 0;   // this is only here so it will compile
}

bool VectorPatientQueue::isEmpty() {
    // TODO: write this function
    return false;   // this is only here so it will compile
}

void VectorPatientQueue::newPatient(string name, int priority) {
    // TODO: write this function
}

string VectorPatientQueue::processPatient() {
    // TODO: write this function
    return "";   // this is only here so it will compile
}

void VectorPatientQueue::upgradePatient(string name, int newPriority) {
    // TODO: write this function
}

string VectorPatientQueue::toString() {
    // TODO: write this function
    return ""; // this is only here so it will compile
}
