// heappatientqueue.cpp
// THIS IS AN EXTENSION AND NOT REQUIRED FOR THE ASSIGNMENT
// This is the CPP file you will edit and turn in. (TODO: Remove this comment!)

#include "HeapPatientQueue.h"

HeapPatientQueue::HeapPatientQueue() {
    // TODO: write this constructor
}

HeapPatientQueue::~HeapPatientQueue() {
    // TODO: write this destructor
}

void HeapPatientQueue::clear() {
    // TODO: write this function
}

string HeapPatientQueue::frontName() {
    // TODO: write this function
    return "";   // this is only here so it will compile
}

int HeapPatientQueue::frontPriority() {
    // TODO: write this function
    return 0;   // this is only here so it will compile
}

bool HeapPatientQueue::isEmpty() {
    // TODO: write this function
    return false;   // this is only here so it will compile
}

void HeapPatientQueue::newPatient(string name, int priority) {
    // TODO: write this function
}

string HeapPatientQueue::processPatient() {
    // TODO: write this function
    return "";   // this is only here so it will compile
}

void HeapPatientQueue::upgradePatient(string name, int newPriority) {
    // TODO: write this function
}

string HeapPatientQueue::toString() {
    // TODO: write this function
    return ""; // this is only here so it will compile
}
